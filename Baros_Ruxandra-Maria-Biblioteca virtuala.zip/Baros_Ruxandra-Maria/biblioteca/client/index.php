<?php
$sort = $_GET['sort'] ?? 'title';
$order = $_GET['order'] ?? 'asc';

$response = file_get_contents("http://localhost/biblioteca/api/books.php?sort=$sort&order=$order");
$books = json_decode($response, true);

function toggle_order($current) {
    return $current === 'asc' ? 'desc' : 'asc';
}
function sort_arrow($field, $currentSort, $currentOrder) {
    if ($field !== $currentSort) return '';
    return $currentOrder === 'asc' ? '↑' : '↓';
}
?>

<style>
a:link, a:visited {
  color: purple; 
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

a:hover, a:active {
  background-color: pink;
}
</style>
<body bgcolor="#f5e2ba" align="center">
<h1>Lista de cărți</h1>

<button onclick="document.location='add_book.php'" style="background-color: #F1E3F7;">Adaugă carte</button>
<br><br>
<table border="1" align="center" style="background-color:#F1E3F7;">
    <tr>
    <th>
        <a href="?sort=title&order=<?= toggle_order($order) ?>">
            Titlu <?= sort_arrow('title', $sort, $order) ?>
        </a>
    </th>
    <th>
        <a href="?sort=author&order=<?= toggle_order($order) ?>">
            Autor <?= sort_arrow('author', $sort, $order) ?>
        </a>
    </th>
    <th>
        <a href="?sort=year&order=<?= toggle_order($order) ?>">
            An <?= sort_arrow('year', $sort, $order) ?>
        </a>
    </th>
    <th>Acțiuni</th>
</tr>

    <?php if (is_array($books)): ?>
        <?php foreach ($books as $book): ?>
            <tr>
                <td><?= htmlspecialchars($book['title']) ?></td>
                <td><?= htmlspecialchars($book['author']) ?></td>
                <td><?= htmlspecialchars($book['year']) ?></td>
                <td>
                    <a href="edit_book.php?id=<?= $book['id'] ?>">Editează</a> |
                    <a href="delete_book.php?id=<?= $book['id'] ?>">Șterge</a>
                </td>
            </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr><td colspan="4">Nu s-au putut încărca cărțile.</td></tr>
    <?php endif; ?>
</table>
