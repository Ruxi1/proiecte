<?php
$id = $_GET['id'];
$response = file_get_contents("http://localhost/biblioteca/api/books.php?id=$id");
$book = json_decode($response, true);

if (isset($book['error'])) {
    echo "Eroare: " . $book['error'];
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'id' => (int)$id,
        'title' => $_POST['title'],
        'author' => $_POST['author'],
        'year' => (int)$_POST['year']
    ];
    $options = [
        'http' => [
            'header'  => "Content-type: application/json",
            'method'  => 'PUT',
            'content' => json_encode($data)
        ]
    ];
    $context = stream_context_create($options);
    file_get_contents('http://localhost/biblioteca/api/books.php', false, $context);
    header('Location: index.php');
    exit;
}
?>
<body bgcolor="#f5e2ba" align="center">
<h2>Editează carte</h2>
<form method="POST">
    Titlu: <input type="text" size="50" name="title" value="<?= $book['title'] ?>" required><br><br>
    Autor: <input type="text" size="40" name="author" value="<?= $book['author'] ?>" required><br><br>
    An: <input type="number" name="year" value="<?= $book['year'] ?>"><br><br>
    <button type="submit" style="background-color: #F1E3F7;">Salvează</button>
</form>
<a href="index.php">Înapoi</a>
