<?php
$id = $_GET['id'] ?? null;

if (!$id) {
    echo "ID-ul cărții nu este specificat.";
    exit;
}


$context = stream_context_create([
    'http' => [
        'method' => 'DELETE'
    ]
]);

file_get_contents("http://localhost/biblioteca/api/books.php?id=$id", false, $context);


header('Location: index.php');
exit;

