<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'title' => $_POST['title'],
        'author' => $_POST['author'],
        'year' => (int)$_POST['year']
    ];
    $options = [
        'http' => [
            'header'  => "Content-type: application/json",
            'method'  => 'POST',
            'content' => json_encode($data)
        ]
    ];
    $context = stream_context_create($options);
    file_get_contents('http://localhost/biblioteca/api/books.php', false, $context);
    header('Location: index.php');
    exit;
}
?>
<body bgcolor="#f5e2ba" align="center">
<h2>Adaugă carte</h2>
<form method="POST">
    Titlu: <input type="text" size="50" name="title" required><br><br>
    Autor: <input type="text" size="40" name="author" required><br><br>
    An: <input type="number" name="year"><br><br>
    <button type="submit" style="background-color: #F1E3F7;">Adaugă</button>
</form>
<a href="index.php">Înapoi</a>
