<?php
$host = 'localhost';
$db = 'biblioteca';
$user = 'root';
$pass = ''; 

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die(json_encode(['error' => 'Conexiune eșuată']));
}
?>
