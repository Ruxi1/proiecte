<?php
header('Content-Type: application/json');
require 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
    if (isset($_GET['id'])) {
        $id = (int)$_GET['id'];
        $stmt = $conn->prepare("SELECT * FROM books WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $book = $result->fetch_assoc();

        if ($book) {
            echo json_encode($book);
        } else {
            echo json_encode(['error' => 'Cartea nu a fost găsită']);
        }
    } else {
        $allowedFields = ['title', 'author', 'year'];
		$allowedOrder = ['asc', 'desc'];

		$sort = in_array($_GET['sort'] ?? '', $allowedFields) ? $_GET['sort'] : 'title';
		$order = in_array(strtolower($_GET['order'] ?? ''), $allowedOrder) ? strtoupper($_GET['order']) : 'ASC';

		$stmt = $conn->prepare("SELECT * FROM books ORDER BY $sort $order");
		$stmt->execute();
		$result = $stmt->get_result();

		$books = [];
		while ($row = $result->fetch_assoc()) {
			$books[] = $row;
		}
		echo json_encode($books);
		}
		break;


    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $stmt = $conn->prepare("INSERT INTO books (title, author, year) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $data['title'], $data['author'], $data['year']);
        $stmt->execute();
        echo json_encode(['message' => 'Carte adăugată']);
        break;

    case 'PUT':
        $data = json_decode(file_get_contents("php://input"), true);
        $stmt = $conn->prepare("UPDATE books SET title=?, author=?, year=? WHERE id=?");
        $stmt->bind_param("ssii", $data['title'], $data['author'], $data['year'], $data['id']);
        $stmt->execute();
        echo json_encode(['message' => 'Carte actualizată']);
        break;

    case 'DELETE':
    $id = $_GET['id'] ?? null;

    if (!$id) {
        echo json_encode(['error' => 'ID-ul nu a fost specificat pentru ștergere']);
        break;
    }

    $stmt = $conn->prepare("DELETE FROM books WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    echo json_encode(['message' => 'Carte ștearsă']);
    break;

    default:
        echo json_encode(['error' => 'Metodă HTTP invalidă']);
        break;
}
?>
