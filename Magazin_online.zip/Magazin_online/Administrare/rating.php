<?php
 session_start();
 include("conectare.php");
 include("autorizare.php");
 include("admin_top.php"); 

$id_produs=$_GET['id_produs'];
$sql="Select * from rating where id_produs=".$id_produs;
$sursa=mysqli_query($conn, $sql);
?>
<h1 align="center">Rating pentru produsul cu id=<?=$id_produs?></h1>

<?php
While($row=mysqli_fetch_array($sursa))
{
	?>
	
<div style="margin:auto; width:500px; border:1px solid #ffffff; 
     background-color:#F1E3F7; padding:5px"> 
	 
	 <b>Nume: <?=$row['nume_utilizator']?></b><br>
	 Email: <a href="mailto:<?=$row['email']?>"><?=$row['email']?></a><br>
	 Rating: 
	 <?php
	 
	 if($row['stele']=='1')
		{
			?>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star"></span>
			<span class="fa fa-star"></span>
			<span class="fa fa-star"></span>
			<span class="fa fa-star"></span>
			<?php
		}
		if($row['stele']=='2')
		{
			?>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star"></span>
			<span class="fa fa-star"></span>
			<span class="fa fa-star"></span>
			<?php
		}
		if($row['stele']=='3')
		{
			?>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star"></span>
			<span class="fa fa-star"></span>
			<?php
		}
		if($row['stele']=='4')
		{
			?>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star"></span>
			<?php
		}
		if($row['stele']=='5')
		{
			?>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<?php
		}
	 ?>
	 
</div>
<?php
}

?>