<?php
 session_start();
 include("conectare.php");
 include("autorizare.php");
 include("admin_top.php"); 
?>
<h1>Modificare sau stergere comentarii utilizatori</h1>
<b>Comentariile utilizatorilor de la ultima moderare</b>
<?php
 $sql = "select * from comentarii, admin, produse, marci where 
			  id_comentariu>admin.ultimul_comentariu_moderat and 
			  produse.id_produs=comentarii.id_produs and 
			  produse.id_marca=marci.id_marca 
			  order by id_comentariu asc"; 
$resursa = mysqli_query($conn, $sql); 

 while($row=mysqli_fetch_array($resursa)){

?>

  <form action="formulare_moderare_opinii.php" method="POST">
    <div style="width:500px; border:1px solid #ffffff; 
     background-color:#F1E3F7; padding:5px">     

     <b><?=$row['titlu']?></b> de: <?=$row['marca']?>
     <hr size="1"> 
         <a href="mailto:<?=$row['adresa_email']?>"><?=$row['nume_utilizator']?></a><br>
                                                                                       <?=$row['comentariu']?> 
    </div>

    <INPUT type="hidden" name="id_comentariu" value="<?=$row['id_comentariu']?>">
    <INPUT type="submit" name="modifica" value="Modifica" class="buton"> 
    <INPUT type="submit" name="sterge" value="Sterge" class="buton">
  </form>
<?php

 $ultimul_id = $row['id_comentariu'];  

 /*Aceasta variabila preia la fiecare iterare cu while a array-ului valoarea id_comentariu, ajungand   
    ca la ultima iterare sa aiba valoarea id-ului ultimului comentariu. Avem nevoie de aceasta  
    valoare astfel incat sa putem seta valoarea campului ultimul_comentariu_moderat din tabelul 
    admit folosind formularul urmator.  */
 } 
 /*In continuare vom scrie o structura conditionala.
   Daca sunt comentarii in lista afisam formularul si butonul de setare a comentariilor ca fiind 
   moderate. Daca nu este nici un comentariu in lista vom afisa doar un mesaj. Astfel evitam  
   erorile care ar putea aparea daca nu avem comentarii in lista si valoarea variabilei 
   $ultimul_comentariu ar fi nula. */
 $nrComentarii=mysqli_num_rows($resursa); 
 if($nrComentarii > 0){ 
?>

<form action="formulare_moderare_opinii.php" method="POST">
 <INPUT type="hidden" name="ultimul_id" value="<?=$ultimul_id?>">
 <INPUT type="submit" name="seteaza_moderate" value="Seteaza aceste comentarii ca fiind moderate" class="buton">
</form> 
<?php

  }else{
	print "NU exista comentarii noi!!";
  }

?>
<h1 align="center">Toate comentariile</h1>
<?php
 $sql = "select * from comentarii, produse, marci where  
			  produse.id_produs=comentarii.id_produs and 
			  produse.id_marca=marci.id_marca 
			  order by id_comentariu asc"; 
$resursa = mysqli_query($conn, $sql); 

 while($row=mysqli_fetch_array($resursa)){

?>
<div style="margin:auto; width:500px; border:1px solid #ffffff; 
     background-color:#F1E3F7; padding:5px">     

     <b><?=$row['titlu']?></b> de: <?=$row['marca']?>
     <hr size="1"> 
         <a href="mailto:<?=$row['adresa_email']?>"><?=$row['nume_utilizator']?></a><br>
                                                                                       <?=$row['comentariu']?> 
    </div>
<?php
 }
 ?>
</body> 
</html>
