<?php
  session_start();
  include("autorizare.php");
  include("admin_top.php");
  include("conectare.php");
  
if(isset($_POST['adauga_tip']))
{
  /*
  inainte de a introduce noul nume de tip verificam doua lucruri:
	-campul sa nu fie gol,
	-sa nu existe deja in tabela
  */
  if($_POST['tip_nou'] == "")
  {
	print 'Trbuie sa completati numele tipului! <br>
        <a href="adaugare.php">Back</a>';
        exit;
  }
  /*verificam daca nu exista deja in tabela*/
 $sql="select * from tipuri where tip='".$_POST['tip_nou']."'";
  $sursa=mysqli_query($conn, $sql);

  /*interogarea returneaza 0 randuri daca tipul nu exista in tabela. 
    Daca nu returneaza 0 inseamna ca tipul exista deja in tabela, 
    nu-l vom mai introduce inca o data, vom atentiona utilizatorul de eroare 
    si vom intrerupe executia scriptului 
  */
  if(mysqli_num_rows($sursa) != 0)
  {
	print 'Tipul <b>'.$_POST['tip_nou'].'</b> exista deja in baza de date!<br>
               <a href="adaugare.php">Back</a>';
        exit;
  }
  else{
   /*adaugam noul nume de tip in tabela*/

  $sql="insert into tipuri(tip) values('".$_POST['tip_nou']."')";
  mysqli_query($conn, $sql);

  /*afisam utilizatorului un mesaj de confirmare*/   
	print 'Tipul <b>'.$_POST['tip_nou'].'</b> a fost adaugat in tabela!<br>
               <a href="adaugare.php">Back</a>';
        exit;
}
}

if(isset($_POST['adauga_marca']))
{
  /*
  inainte de a introduce noul nume de marca verificam doua lucruri:
	-campul sa nu fie gol,
	-sa nu existe deja in tabela
  */
  if($_POST['marca_nou'] == "")
  {
	print 'Trbuie sa completati numele marcii! <br>
        <a href="adaugare.php">Back</a>';
        exit;
  }
  /*verificam daca nu exista deja in tabela*/
 $sql="select * from marci where marca='".$_POST['marca_nou']."'";
  $sursa=mysqli_query($conn, $sql);

  /*interogarea returneaza 0 randuri daca tipul nu exista in tabela. 
    Daca nu returneaza 0 inseamna ca tipul exista deja in tabela, 
    nu-l vom mai introduce inca o data, vom atentiona utilizatorul de eroare 
    si vom intrerupe executia scriptului 
  */
  if(mysqli_num_rows($sursa) != 0)
  {
	print 'Marca <b>'.$_POST['marca_nou'].'</b> exista deja in baza de date!<br>
               <a href="adaugare.php">Back</a>';
        exit;
  }
  else{
  
   /*adaugam noul nume de tip in tabela*/

  $sql="insert into marci(marca) values('".$_POST['marca_nou']."')";
  mysqli_query($conn, $sql);

  /*afisam utilizatorului un mesaj de confirmare*/   
	print 'Marca <b>'.$_POST['marca_nou'].'</b> a fost adaugata in tabela!<br>
               <a href="adaugare.php">Back</a>';
        exit;
}
}

  if(isset($_POST['adauga_produs']))
{
   	/*verificam daca titlul, descrierea sau pretul nu sunt goale*/

       if($_POST['titlu'] == "" || $_POST['descriere'] == "" || $_POST['pret'] == "" || $_POST['cantitate'] == "" )
       {
	  print 'Trbuie sa completati toate campurile: titlu, descriere, pret, marca! <br><a href="adaugare.php">Back</a>';
          exit;
       }

       /*verificam daca valoarea introdusa in campul pret este de tip numeric*/

       if(!is_numeric($_POST['pret']))
       {
	  print 'campul pret trebuie sa fie de tip numeric!<br>
	         <a href="adaugare.php">Back</a>';
          exit;
       }
	   
	   /*verificam daca valoarea introdusa in campul cantitate este de tip numeric*/

       if(!is_numeric($_POST['cantitate']))
       {
	  print 'campul cantitate trebuie sa fie de tip numeric!<br>
	         <a href="adaugare.php">Back</a>';
          exit;
       }
	   
	  /*verificam daca aceast produs nu exista deja in tabela*/

       $sql="select * from produse where titlu='".$_POST['titlu']."'";
       $sursa=mysqli_query($conn, $sql);
       if(mysqli_num_rows($sursa) != 0)
       {
		print 'Acest produs exista deja in baza de date! <br>
		<a href="adaugare.php">Back</a>';
  		exit;
       }
	   $target_dir = "imagini/";
	   $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
		$uploadOk = 1;
		$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		
		if(isset($_POST["submit"])) {
		$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
		if($check !== false) {
			echo "File is an image - " . $check["mime"] . ".";
			$uploadOk = 1;
			} else {
				echo "File is not an image.";
			$uploadOk = 0;
			}
		}
		
		if($imageFileType != "jpg" ) {
			echo "Sorry, only JPG files are allowed.";
			$uploadOk = 0;
		}

	  /*am verificat sa nu existe erori, deci putem adauga produse in baza de date*/		

	  $sqladprod="insert into produse(id_tip,id_marca,titlu,descriere,pret,datai,cantitate) values(
						     ".$_POST['id_tip'].",
						     ".$_POST['id_marca'].",
						     '".$_POST['titlu']."',
							 '".$_POST['descriere']."',
						     ".$_POST['pret'].",
							 '".$_POST['datai']."',
							 ".$_POST['cantitate'].")";
	  mysqli_query($conn, $sqladprod);
	  //$sqlid="Select id_produs from produse where titlu='".$_POST['titlu']."'";
	  //$resid=mysqli_query($conn, $sqlid);
	  //$idprod=mysqli_fetch_array($resid);

	  /*afisam utilizatorului un mesaj de confirmare*/
	  
	  $file=mysqli_insert_id($conn);
	  $target_file = $target_dir . basename($file.".jpg");
	  
	  
		
		
		if ($uploadOk == 0) {
			echo "Sorry, your file was not uploaded.";
			// if everything is ok, try to upload file
		} else {
		if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
		{
			echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
			
		} else {
			echo "Sorry, there was an error uploading your file.";
				}
		}
		

	  print 'Produsul a fost adaugat in tabela!<br>
	  	<button> <a href="adaugare.php">Back</a></button>';
	  exit;
	}
?>
</body>
</html>
