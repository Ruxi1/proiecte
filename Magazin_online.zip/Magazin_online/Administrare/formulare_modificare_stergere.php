<?php
 session_start();
 include("autorizare.php"); 
 include("admin_top.php");
 include("conectare.php");

if(isset($_POST['modifica_tip']))
 {

   $sql= "select tip from tipuri where id_tip='".$_POST['id_tip']."'";
   $resursa = mysqli_query($conn, $sql);
   $row = mysqli_fetch_assoc($resursa);
   $tip=$row['tip'];


?>

<h1>Modifica nume tip</h1>

<form action="prelucrare_modificare_stergere.php" method="POST">
    <INPUT type="text" name="tip" value="<?=$tip?>">
    <INPUT type="hidden" name="id_tip" value="<?=$_POST['id_tip']?>">
    <INPUT type="submit" name="modifica_tip" value="Modifica" class="buton"> 
</form>

<?php

}

/*   Sterge tip */


 if(isset($_POST['sterge_tip']))
 {
   /* verificam daca sunt produse in tabela care apartin acestui tip */

   $sql = "select titlu from produse,tipuri 
		where produse.id_tip=tipuri.id_tip and 
		      tipuri.id_tip=".$_POST['id_tip'];
      
   $resursa = mysqli_query($conn, $sql);   
   $nrProduse = mysqli_num_rows($resursa);

   /* daca sunt produse apartinand acestui tip afisam lista lor si un mesaj de eroare */

   if($nrProduse > 0)
   {
	print "<p>Sunt $nrProduse produse care apartin acestui tip</p>";
	while($row = mysqli_fetch_array($resursa))
	{
  			print "<b>".$row['titlu']."<br>";
	}
      print "<p>Nu puteti sterge acest tip </p>";
   }
      /* iar daca nu sunt produse in acest domeniu cerem confirmarea pentru stergere: */
    else{

?>
<h1>Sterge nume tip</h1> 

	Esti sigur ca vrei sa stergi acest tip?

<form action="prelucrare_modificare_stergere.php" method="POST">
   <INPUT type="hidden" name="id_tip" value="<?=$_POST['id_tip']?>">
   <INPUT type="submit" name="sterge_tip" value="Sterge!" class="buton"> 
</form>

<?php
 }
}

/*modifica/sterge marca

  modificare nume marca */ 

 if(isset($_POST['modifica_marca']))
 {
   /* luam numele marcii din tabela deoarece ne-a fost trimis din formular doar id_marca: */
  $sql = "select marca from marci where id_marca='".$_POST['id_marca']."'";
  $resursa = mysqli_query($conn, $sql); 
  $row = mysqli_fetch_assoc($resursa);
  $marca=$row['marca'];

  /* si afisam numele marcii intr-un textbox pentru a fi modificat */

?>
<h1>Modifica nume marca</hl> 

<form action="prelucrare_modificare_stergere.php" method="POST">
   <INPUT type="text" name="marca" value="<?=$marca?>">
   <INPUT type="hidden" name="id_marca" value="<?=$_POST['id_marca']?>">
   <INPUT type="submit" name="modifica_marca" value="Modifica" class="buton"> 
</form>

<?php
 }
/* Sterge marca */

  if(isset($_POST['sterge_marca']))
  {
      /*verificam daca sunt produse in tabela care apartin acestei marci: */
     
     $sql = "select titlu from produse, marci where produse.id_marca=marci.id_marca and
				 produse.id_marca=".$_POST['id_marca']; 
     $resursa = mysqli_query($conn, $sql);
     $nrProduse = mysqli_num_rows($resursa);

     /* daca sunt produse apartinand acestei marci, afisam lista lor si un mesaj de eroare: */
	if($nrProduse > 0)
    {
	print "<p>Sunt $nrProduse produse de acesta marca in tabela!</p>"; 
	while($row = mysqli_fetch_array($resursa))
	{
   		print $row['titlu']."<br>"; 
	}

	print "<p>Nu puteti sterge acesta marca!</p>";
    } 
    /* iar daca nu sunt produse de aceasta marca cerem confirmarea pentru stergere */

    else
	{
?> 
<h1>Sterge marca</h1>

	Esti sigur ca vrei sa stergi aceasta marca?


<form action="prelucrare_modificare_stergere.php" method="POST">
   <INPUT type="hidden" name= "id_marca" value="<?=$_POST['id_marca']?>">
   <INPUT type="submit" name="sterge_marca" value="Sterge!" class="buton">
</form>

<?php
 }
}
  /*modifica/sterge produse
  modificare nume produse */ 

 if(isset($_POST['modifica_produs']))
 {
      print "<h1>Modificare produse</h1>";

      /* cautam intai un produs care are titlul specificat in formular*/

      $sqlProduse="select * from produse where titlu='".$_POST['titlu']."'";
      $resursaProdus=mysqli_query($conn, $sqlProduse);

      /*daca nu s-a gasit nici un produs care sa corepunda datelor introduse, 
	afisam un mesaj de eroare*/

      if(mysqli_num_rows($resursaProdus) == 0)
      {
		print "Acest produs nu exista in tabela";   
      }
	  else
	  {

        /* daca exista, atunci extragem informatiile din resursa, le punem intr-un array 
	  (nu folosim while deoarece este returnat un singur rand!) si le afisam in 
	  formular pentru a fi modificate*/

        $rowProduse = mysqli_fetch_array($resursaProdus);
	
?> 
	<form action="prelucrare_modificare_stergere.php" method="POST">
	<table>
  	<tr>
      	  <td>Tip:</td>
      	  <td><SELECT name="id_tip">
          <?php
           /* Luam numele de tipuri din tabela si Ie afisam utilizatorului intr-o lista drop-   
              down. Observati folosirea lui if pentru a afisa ca selectat tipul de care apartine  
              produsul
           */

           $sql="select * from tipuri order by tip asc";
		   $resursa = mysqli_query($conn, $sql);
		   while($row=mysqli_fetch_array($resursa))
           {
				if($row['id_tip'] == $rowProduse['id_tip'])
				{
					print '<option SELECTED value="'.$row['id_tip'].'">'.$row['tip'].'</option>';
				}
				else
				{
					print '<option value="'.$row['id_tip'].'">'.$row['tip'].'</option>';
				}
           }

          ?>

    	 </select>
       </td> 
      </tr> 
	   <tr> 
       <td>Marca:</td>
       <td>
        <select name="id_marca"> 
          
        <?php

        /* Afisam si lista dropdown cu marci */

        $sql = "select * from marci order by marca asc"; 
        $resursa = mysqli_query($conn, $sql); 
       
        while($row = mysqli_fetch_array($resursa)){
	   if($row['id_marca'] == $rowProduse['id_marca']){
		print '<option SELECTED value="'.$row['id_marca'].'">'.$row['marca'].'</option>';
	   }else{
			print '<option value="'.$row['id_marca'].'">'.$row['marca'].'</option>';
	   }
        }

        ?> 

        </select>
      </td> 
     </tr> 
	 
	 <tr> 
      <td>Titlu:</td>
      <td> 
         <INPUT type="text" name="titlu" value="<?=$rowProduse['titlu']?>">
      </td>
     </tr> 
     <tr> 
      <td valign = "top"> Descriere: </td>
      <td><textarea name = "descriere" rows="8"><?=$rowProduse['descriere']?>
          </textarea>
      </td>
     </tr> 
     <tr> 
      <td>Pret:</td>
      <td>
	<INPUT type="text" name="pret" value="<?=$rowProduse['pret']?>">
      </td>
     </tr>
	 <tr> 
      <td>Cantitate:</td>
      <td>
	<INPUT type="text" name="cantitate" value="<?=$rowProduse['cantitate']?>">
      </td>
     </tr>
   </table> 
    <INPUT type="hidden" name="id_produs" value="<?=$rowProduse['id_produs']?>">
    <INPUT type="submit" name="modifica_produs" value="Modifica" class="buton"> 
 </form>

 <?php
 }
}
 /* si in final stergere produs */

 if(isset($_POST['sterge_produs']))
 {
   print "<h1>Sterge produs</h1>";

   /* cautam intai un produs in tabela care are titlul specificat in 
      formular
   */

   $sqlProduse = "select * from produse where titlu='".$_POST['titlu']."'";
 
   $resursaProdus = mysqli_query($conn, $sqlProduse);

   /* daca nu s-a gasit nici un produs care sa corespunda datelor introduse afisam 
      un mesaj de eroare 
   */

   if(mysqli_num_rows($resursaProdus) == 0)
   {
		print "Aceast produs nu exista in tabela";
   }
   else
   {
        /* iar daca exista atunci extragem id_ul produsului din tabela si il vom folosi 
        intr-un camp ascuns din formularul de confirmare */

		$row = mysqli_fetch_assoc($resursaProdus);
		$id_produs=$row['id_produs'];
   ?>

  Esti sigur ca vrei sa stergi aceast produs ?

  <form action="prelucrare_modificare_stergere.php" method="POST">
    <INPUT type="hidden" name="id_produs" value="<?=$id_produs?>">
    <INPUT type="submit" name="sterge_produs" value="Sterge!" class="buton"> 
  </form>

<?php
 }
}
?>

</body>
</html>



