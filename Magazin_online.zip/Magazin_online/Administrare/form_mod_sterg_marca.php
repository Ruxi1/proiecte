	<form action="prelucrare_modificare_stergere.php" method="POST">
	<table>
  	<tr>
      	  <td>Tip</td>
      	  <td><SELECT name="id_tip">

          <?
           $sql1 = "select * from tipuri order by tip asc";
           $resursa1 = mysqli_query($conn, $sql1);

           while(mysqli_fetch_array($resursa1))
           {
	      if($row['id_tip'] == $rowProdus['id_tip'])
	      {
		print '<option SELECTED value="'.$row['id_tip'].'">'
                                                .$row['tip']
			.'</option>';
              }else{
		print '<option value="'.$row['id_tip'].'">'
				       .$row['tip']
			.'</option>';
              }
            }

          ?>

    	 </select>
       </td> 
      </tr> 
      <tr> 
       <td>Marca:</td>
       <td>
        <select name="id_marca"> 
          
        <?

        /* Afisam si lista dropdown cu autori */

        $sql2 = "select * from marci order by marca asc"; 
        $resursa2 = mysqli_query($conn, $sql2); 
        while($row = mysqli_fetch_array($resursa2))
        {
   	   if($row['id_marca'] == $rowProdus['id_marca'])
	   {
      		print '<option SELECTED value="'.$row('id_marca'].'">'
					        .$row['marca']
                     .'</option>';
   	   }else{
		print '<option value="'.$row['id_marca'].'">'
				       .$row['marca']
		     .'</option>';
   	   }
        }

        ?> 

        </select>
      </td> 
     </tr> 
     <tr> 
      <td>Titlu:</td>
      <td> 
         <INPUT type="text" name="titlu" value="<?=$rowProdus['titlu']?>">
      </td>
     </tr> 
     <tr> 
      <td valign = "top"> Descriere: </td>
      <td><textarea name = "descriere" rows="8"><?=$rowProdus['descriere']?>
          </textarea>
      </td>
     </tr> 
     <tr> 
      <td>Pret:</td>
      <td>
	<INPUT type="text" name="pret" value="<?=$rowProdus['pret']?>">
      </td>
     </tr>
   </table> 
    <INPUT type="hidden" name="id_produs" value="<?=$rowProdus['id_produs']?>">
    <INPUT type="submit" name="modifica_produs" value="Modifica"> 
 </form>