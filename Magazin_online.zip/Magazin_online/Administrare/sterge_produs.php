 if(isset($_POST['sterge_produs']))
 {
   print "<h1>Sterge produs</h1>";

   /* cautam intai un produs in tabela care are titlul  specificat in 
      formular
   */

   $sqlProduse = "select * from produse where titlu='".$_POST['titlu'];
 
   $resursaProdus = mysql_query($sqlProduse);

   /* daca nu s-a gasit nici un produs care sa corespunda datelor introduse atisam 
      un mesaj de eroare 
   */

   if(mysql_num_rows($resursaProdus) == 0)
   {
	print "Aceast produs nu exista in tabela";
   }else{
  	/* iar daca exista atunci extragem id_ul produsului din tabela si il vom folosi 
                intr-un camp ascuns din formularul de confirmare */

   $id_produs = mysql_result($resursaProdus,0,"id_produs");

 ?>

Esti sigur ca vrei sa stergi aceast produs?

<form action="prelucrare_modificare_stergere.php" method="POST">
   <INPUT type="hidden" name="id_produs" value ="<?=$_POST['id_produs']?>">
   <INPUT type="submit" name="sterge_produs" value="Sterge!"> 
</form>

<?
 }
}
?>