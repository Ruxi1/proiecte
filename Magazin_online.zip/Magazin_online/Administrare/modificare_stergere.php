<?php
  session_start();
  include("autorizare.php");
  include("admin_top.php");
  include("conectare.php");
?>

<h2 align="center">Modificare sau stergere</h2>

<p><b>Nota:</b>Nu veti putea sterge tipuri/marci care au produse asociate lor.<br>Inainte de a sterge tipul/marca,
 modificati produsele din el astfel incat sa apartina altor tipuri/marci. <br>
 
 </p>
<div style="width:600px; margin-left: auto;
  margin-right: auto; border:3px solid #632415; 
   background-color: #F1E3F7; padding:5px">
<b>Selecteaza tipul pe care doresti sa-l modifici sau sa-l stergi:</b>
<hr size="1">
<form action="formulare_modificare_stergere.php" method="POST">
  Tip:
  <select name="id_tip" >
    <?php
     $sql = "select * from tipuri order by tip asc";
     $resursa = mysqli_query($conn, $sql);
     while($row = mysqli_fetch_array($resursa))
     {
          print '<option value="'.$row['id_tip'].'">'.$row['tip'].'</option>';
     }
   ?>

  </select>

  <INPUT type="submit" name="modifica_tip" value="Modifica" class="buton">
  <INPUT type="submit" name="sterge_tip" value="Sterge" class="buton">
</form>
</div>

<div style="width:600px; margin-left: auto;
  margin-right: auto; border:3px solid #632415; 
   background-color: #F1E3F7; padding:5px">

<b>Selecteaza marca pe care doresti sa o modifici sau sa o stergi:</b>
<hr>
<form action="formulare_modificare_stergere.php" method="POST">
  Marca:
  <select name="id_marca">

  /*afisam si lista drop-down cu marci*/
  <?php
    $sql = "select * from marci order by marca asc";
    $resursa = mysqli_query($conn, $sql); 
    while($row = mysqli_fetch_array($resursa)){
        print '<option value="'.$row['id_marca'].'">'.$row['marca'].'</option>';
    }
  ?> 
 </select> 

    <INPUT type="submit" name ="modifica_marca" value="Modifica" class="buton">
    <INPUT type="submit" name ="sterge_marca" value="Sterge" class="buton">

</form>
</div>
<div style="width:600px; margin-left: auto;
  margin-right: auto; border:3px solid #632415; 
   background-color: #F1E3F7; padding:5px">

<b>Selecteaza marca si scrie titlul produsului pe care doresti sa il modifici sau sa il stergi:</b>
<hr>


<form action="formulare_modificare_stergere.php" method="POST">
 <table>
   <tr>
    <td>Marca:</td>
    <td>
     <select name="id_marca">

       <?php
	/*afisam si lista drop-down cu marci*/

	$sql = "select * from marci order by marca asc";
	$resursa = mysqli_query($conn, $sql); 
	while($row = mysqli_fetch_array($resursa)){
		print '<option value="'.$row['id_marca'].'">'.$row['marca'].'</option>';
	}
       ?> 
     </select> 
   </td>
  </tr> 
  <tr><td>Titlu:</td>
      <td><INPUT type="text" name="titlu"></td>
  </tr> 
 </table> 
    <INPUT type="submit" name="modifica_produs" value="Modifica" class="buton"> 
    <INPUT type="submit" name="sterge_produs" value="Sterge" class="buton">      
 </form>

</div>

</body> 
</html>

