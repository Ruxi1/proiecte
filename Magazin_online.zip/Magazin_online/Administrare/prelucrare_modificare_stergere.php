<?php
  session_start();
  include("autorizare.php");
  include("admin_top.php");
  include("conectare.php");

/* modificare nume tip */ 
if(isset($_POST['modifica_tip']))
{
  /* Verificam daca noul nume de tip a fost introdus. */ 
  if($_POST['tip']=="")
  {
 	print "Nu ati introdus numele tipului ! ";
  }
  else
  {
    $sql = "update tipuri set tip='".$_POST['tip']."' 
				where id_tip=".$_POST['id_tip'];
	mysqli_query($conn, $sql);
 	/*print '<br>'.$sql.'<br>';*/
 	print "numele tipului a fost modificat!";
  }

  /* De ce nu am folosi exit in structura if(conditie) {codul de executat; exit}; ? Pentru 
  ca, daca nu se executa codul din if (conditie) {} , se executa codul din else {} si atunci 
  exit ar fi superfluu. */
}
/* stergere tip */

if(isset($_POST['sterge_tip']))
{
   $sql="delete from tipuri where id_tip=".$_POST['id_tip'];
   mysqli_query($conn, $sql);
   print "Tipul a fost sters!";
}

/* modificare nume marca */ 

if(isset($_POST['modifica_marca'])){
	/* Verificam daca numele modificat al marcii a fost introdus. */
	if($_POST['marca']==""){
		print "Nu ati introdus numele marcii";
	}else{
		$sql="update marci set marca='".$_POST['marca']."'  
                                	where id_marca=".$_POST['id_marca'];
		mysqli_query($conn, $sql);
		print "Numele marcii a fost modificat!";
	}
}
/* Stergere marca */ 

if(isset($_POST['sterge_marca'])){
	$sql = "delete from marci where id_marca=".$_POST['id_marca'];
	mysqli_query($conn, $sql);
	print "Marca a fost stearsa!";
}

/* Modificare informatii produs */ 

if(isset($_POST['modifica_produs']))
{
	/* Verificam daca toate datele au fost introduse corect. N-am vrea sa 
	introducem date eronate in tabela doar pentru ca a sarit pisica pe 
	tastatura si a apasat ENTER in timp ce introduceam datele. Daca, credeti  
	nu vi se poate intampla ... ei bine, din proprie experienta va spun ca se 
	ca poate. Vom folosi o structura  if  ... else if ... else: */

	if($_POST['titlu'] == "")
	{
   		print "Nu ati introdus titlul !";
	}
    else if($_POST['descriere'] == "")
	{
    	print "Nu ati introdus descrierea !";
	}
    else if($_POST['pret'] == "")
	{
    	print "Nu ati introdus pretul !";
	}
    else if(!is_numeric($_POST['pret']))
	{
		print "Pretul trebuie sa fie numeric! ";
	}
	else if($_POST['cantitate'] == "")
	{
    	print "Nu ati introdus cantitatea !";
	}
    else if(!is_numeric($_POST['cantitate']))
	{
		print "Cantitatea trebuie sa fie numeric! ";
	}
	else
	{
		$sql="update produse set 
			id_tip=".$_POST['id_tip'].",
			id_marca=".$_POST['id_marca'].",
			titlu='".$_POST['titlu']."',
			descriere='".$_POST['descriere']."',
			pret=".$_POST['pret'].",
			cantitate=".$_POST['cantitate']."
			where id_produs=".$_POST['id_produs']; 
		 /*print '<br>'.$sql.'<br>';*/
		mysqli_query($conn, $sql); 
		print "Informatiile au fost modificate!";
  }
}

/* Stergere Produs */

if(isset($_POST['sterge_produs']))
{
	$sqlProdus="delete from produse where id_produs=".$_POST['id_produs']; 
	mysqli_query($conn, $sqlProdus); 
    $sqlComentarii="delete from comentarii where id_produs=".$_POST['id_produs']; 
	mysqli_query($conn, $sqlComentarii);
    print "Produsul a fost sters din tabela!";
}

?> 

</body>
</html>