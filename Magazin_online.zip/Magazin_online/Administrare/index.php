<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
	<title>Magazin online</title></head>
	<style type="text/css">
	body, p, td {font-family: Verdana, Arial, sans-serif; font-size: 12px;}
	h1 {font-family: Times New Roman, Times, serif; font-size: 18px; font-weight: bold; 
	color: #336699; font-style: italic;}.
	titlu {font-family: Verdana, Arial, sans-serif; font-size: 14px; font-weight: bold; color: #0066CC;}
	.buton
  {
	  background-color: #833D97;
      color: #FFFFFF;
  }
	</style>
</head>
<body bgcolor="#ffffff">
<img src="logo.jpg">
<h2 align="center">Autentificare</h2>
<form action="login.php" method="POST">
  <table align="center">
   <tr>
    <td>Nume : <INPUT TYPE="text" NAME="nume"></td>
   </tr>
   <tr>
    <td>Parola : <INPUT TYPE="password" NAME="parola" SIZE="16"></td>
   </tr>
   <tr>
    <td><INPUT TYPE="SUBMIT" VALUE="Autentificare" class="buton"></td>
   </tr>
  </table>
</form>

</body>
</html>
