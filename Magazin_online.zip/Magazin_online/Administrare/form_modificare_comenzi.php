<?php
 session_start();
 include("autorizare.php"); 
 include("admin_top.php");
 include("conectare.php");
if(isset($_POST['modifica_comanda']))
 {
	 $sqlTranz="Select * from tranzactii where id_tranz=".$_POST['id_tranz'];
	 $sursaTranz=mysqli_query($conn, $sqlTranz);
	 $rowTranzactie=mysqli_fetch_assoc($sursaTranz);
	 ?>
	 <p> Data  comenzii:

 <b><?=$rowTranzactie['data_tranz']?></b></p>
  

 <b><?=$rowTranzactie['nume_cump']?></b><br>
	<u>mail:</u><a href="mailto:<?=$rowTranzactie['email']?>"><?=$rowTranzactie['email']?></a><br>
	<u>Telefon:</u><?=$rowTranzactie['telefon']?><br>
	<u>Extra:</u><?=$rowTranzactie['extra']?><br>
    <u>Adresa:</u><?=$rowTranzactie['adr_cump']?><br>
	
	<TABLE border="1" cellpadding="4" cellspacing="0">
  <tr>
    
	<td align="center"><b>Produs titlu</b></td>
    <td align="center"><b>Nr.buc</b></td>
    <td align="center"><b>Pret</b></td>
    <td align="center"><b>Total</b></td>
  </tr>
  
	 <?php
	 $totalGeneral = 0;
	 $sqlProdus = "select titlu,pret,nr_buc from vanzari,produse
                        where produse.id_produs=vanzari.id_produs and 
                        vanzari.id_tranz=".$rowTranzactie['id_tranz'];
 
  $resursaProdus=mysqli_query($conn, $sqlProdus); 

	while($rowProduse=mysqli_fetch_array($resursaProdus))
  { 
        
		print '<tr><td>'.$rowProduse['titlu'].'</td>';
        print '<td align="right">'.$rowProduse['nr_buc'].'</td>';
        print '<td align="right">'.$rowProduse['pret'].'</td>';

  $total=$rowProduse['pret']*$rowProduse['nr_buc'];
  
  print '<td align="right">'.$total.'</td></tr>';

  $totalGeneral = $totalGeneral + $total;

  }
  
  ?>
  <tr><td  colspan="3" align="right"><b>Total comanda</b></td> 
     <td><b><?=$totalGeneral?> lei </b></td> 
 </tr> 
</table>
<br>
	 <form action="add_prod_comanda.php" method="POST">
	 <INPUT type="hidden" name="id_tranz"  value="<?=$rowTranzactie['id_tranz']?>">
	 
	 Id produs:<INPUT type="text" name="id_produs"><br><br>
	 Nr. bucati:<INPUT type="text" name="nr_buc">
	 
	 <INPUT type="submit" name="adauga_produs" value="Adauga produs" class="buton"><br><br>
	 </form>
	 
	 <form action="sterge_prod_comanda.php" method="POST">
	 <INPUT type="hidden" name="id_tranz"  value="<?=$rowTranzactie['id_tranz']?>">
	 Id produs:<INPUT type="text" name="id_produs">
	 
	 <INPUT type="submit" name="sterge_produs" value="Sterge produs" class="buton">
	 <?php
	 
 }
 
 
?>