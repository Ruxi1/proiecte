
 if(isset($_POST['sterge_tip']))
 {
   /* verificam daca sunt produse in tabela care apartin acestui domeniu */

   $sql = "select titlu from produse,tipuri 
		where produs.id_tip=domenii.id_tip";
   $resursa = mysql_query($sql);
   $nrProduse = mysql_num_rows($resursa);

   /* daca sunt produse apartinand acestui domeniu afisam lista lor si un mesaj de eroare */

   if($nrProduse > 0)
   {
	print "<p>Sunt $nrProduse produse care apartin acestui tip</p>";
	while($row = mysql_fetch_array($resursa))
	{
  			print "<b>".$row['titlu']."</b>";
	}
	print "<p>Nu puteti sterge acest tip </p>";

	/* iar daca nu sunt produse in acest tip cerem confirmarea pentru stergere: */
 }else{

?>

<h1>Sterge nume tip</h1> 
	Esti sigur ca vrei sa stergi acest tip?
<form action="prelucrare_modificare_stergere.php" method="POST">
   <INPUT type="hidden" name="id_tip" value="<?=$_POST['id_tip']?>">
   <INPUT type="submit" name="sterge_tip" value="Sterge!"> 
</form>

<?
 }
}
?>