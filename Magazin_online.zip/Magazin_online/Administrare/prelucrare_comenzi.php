<?php
 session_start();
 include("autorizare.php"); 
 include("admin_top.php");
 include("conectare.php");
 print ("<h2>Comenzi</h2>"); 
/* comanda a fost onoratã*/
 if(isset($_POST['comanda_onorata']))
{
	 /*setãm câmpul comanda_onorata în tabela tranzactii pentru aceastã comandã */
	$sql = "update tranzactii set comanda_onorata=1 where id_tranz=".$_POST['id_tranz'];
	mysqli_query($conn, $sql);
	
	//modificam antitatea produselor comandate
	$sqlSel="Select * from vanzari where id_tranz=".$_POST['id_tranz'];
	$sursa=mysqli_query($conn,$sqlSel);
	
	while($row=mysqli_fetch_array($sursa))
	{
		$sqlCant="update produse set cantitate=cantitate-'".$row['nr_buc']."' where id_produs=".$row['id_produs'];
		mysqli_query($conn, $sqlCant);
	}
	
	/* si afisam un mesaj*/
	print "Comanda a fost onorata"; 
}
/* comanda a fost anulatã */

if(isset($_POST['anuleaza_comanda']))
{
	/* Stergem tranzactia (din tabelul tranzactii.) si produsele comandate (din tabelul vanzari)*/
	$sqlVanz = "delete from vanzari where id_tranz=".$_POST['id_tranz'];
	mysqli_query($conn, $sqlVanz);
	
	
	
	$sqlTranzactii = "delete from tranzactii where id_tranz=".$_POST['id_tranz']; 
	mysqli_query($conn, $sqlTranzactii); 

	

	 /* si afisam un mesaj*/

	print "Comanda a fost anulata!"; 
}
?>
</body> 
</html>