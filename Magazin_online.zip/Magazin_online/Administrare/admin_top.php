<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>Magazin online</title>
	<style type="text/css">
	.checked {
  color: orange;
}
	body, p, td 
	{font-family: Verdana, Arial, sans-serif; font-size: 12px;}
	h1 
{font-family: Times New Roman, Times, serif; font-size: 18px; 
	font-weight: bold; color: #8839AB; font-style: italic;}
	.titlu 
{font-family: Verdana, Arial, sans-serif; font-size: 14px; font-weight: bold; color: #0066CC;}
	
	.buton
  {
	  background-color: #833D97;
      color: #FFFFFF;
  }
  a:link {
  color: purple;
	}
  a:visited {
	color: purple;
	}
	a:hover {
  color: red;
}
  
	</style>
</head>

<body bgcolor="#ffffff" background="imgp.png">
<img src="logo.jpg">
<table bgcolor="#F1E3F7" cellspacing="0" cellpadding="4" border="1">
 <tr>
  <td><a href="adaugare.php">Adaugare</a></td>
  <td><a href="modificare_stergere.php">Modificare/Stergere</a></td>
  <td><a href="opinii.php">Opinii vizitatori</a></td>
  <td><a href="comenzi.php">Comenzi</a></td>
  <td><a href="produse.php">Produse</a></td>
 </tr>
</table>
<br>
