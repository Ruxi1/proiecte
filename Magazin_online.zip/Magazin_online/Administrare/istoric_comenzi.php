<?php
 session_start();
 include("conectare.php");
 include("admin_top.php");
?>
<h2 align="center">Comenzi</h1>
<h1 align="center">Comenzi onorate</h1>

<?php


$sqlTranzactii = "select id_tranz, DATE_FORMAT(data_tranz,'%d-%m-%y')
                 as data_tranz, nume_cump, email, telefon, adr_cump, extra from tranzactii where comanda_onorata=1";


$resursaTranzactii = mysqli_query($conn, $sqlTranzactii);
while($rowTranzactie = mysqli_fetch_array($resursaTranzactii))
{
   $totalGeneral = 0;                
?>
<p align="center"> Data  comenzii:

 <b><?=$rowTranzactie['data_tranz']?></b></p>
 <div style="margin:auto;width:400px; border:solid ;border-color:#632415; background-color:#F1E3F7; padding:5px"> 

 <b><?=$rowTranzactie['nume_cump']?></b><br>
	<u>mail:</u><a href="mailto:<?=$rowTranzactie['email']?>"><?=$rowTranzactie['email']?></a><br>
	<u>Telefon:</u><?=$rowTranzactie['telefon']?><br>
	<u>Extra:</u><?=$rowTranzactie['extra']?><br>
    <u>Adresa:</u><?=$rowTranzactie['adr_cump']?>
	
	<TABLE border="1" cellpadding="4" cellspacing="0">
  <tr>
    <td align="center"><b>Produs</b></td>
    <td align="center"><b>Nr.buc</b></td>
    <td align="center"><b>Pret</b></td>
    <td align="center"><b>Total</b></td>
  </tr>

<?php
  $sqlProdus = "select titlu,pret,nr_buc from vanzari,produse
                        where produse.id_produs=vanzari.id_produs and 
                        vanzari.id_tranz=".$rowTranzactie['id_tranz'];
 
  $resursaProdus=mysqli_query($conn, $sqlProdus); 

	while($rowProduse=mysqli_fetch_array($resursaProdus))
  { 
        print '<tr><td>'.$rowProduse['titlu'].'</td>';
        print '<td align="right">'.$rowProduse['nr_buc'].'</td>';
        print '<td align="right">'.$rowProduse['pret'].'</td>';

  $total=$rowProduse['pret']*$rowProduse['nr_buc'];
  
  print '<td align="right">'.$total.'</td></tr>';

  $totalGeneral = $totalGeneral + $total;

  }

?>
 <tr><td  colspan="3" align="right"><b>Total comanda</b></td> 
     <td><b><?=$totalGeneral?> lei </b></td> 
 </tr> 
</table>
</div> 
<br>
<?php 

}

?>

</body>
</html>