<?php
include("autorizare.php");
include("admin_top.php");

print "<br><b>Pagina principala</b><br>";
?>