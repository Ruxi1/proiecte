<?php
  session_start();
  include("autorizare.php");
  include("admin_top.php");
  include("conectare.php");
  
  if(isset($_POST['sterge_produs']))
{
  /* Verificam daca noul nume de tip a fost introdus. */ 
  if($_POST['id_produs']=="")
  {
 	print "Nu ati introdus id-ul produsului! ";
  }
  else
  {
    $sql = "delete from vanzari where id_tranz=".$_POST['id_tranz']." and id_produs=".$_POST['id_produs'];
	mysqli_query($conn, $sql);
 	/*print '<br>'.$sql.'<br>';*/
 	print "produsul a fost sters!";
  }
}
?>