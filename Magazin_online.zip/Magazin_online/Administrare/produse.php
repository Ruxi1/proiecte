<?php
include("conectare.php");
include("admin_top.php");
?>
<table border="3" align="center" bgcolor="#F1E3F7">
<button onClick="window.print()" style="background-color: #833D97;color: #FFFFFF;">Print this page</button>

<caption><b>Tabel produse</b></caption>
<thead align="center" >
	<tr>
		<th> Id produs </th>
		<th> Imagine </th>
		<th> Titlu </th>
		<th> Rating </th>
		<th> Tip </th>
		<th> Marca </th>
		<th> Descriere </th>
		<th> Pret </th>
		<th> Data intrare </th>
		<th> Cantitate </th>
	</tr>
	<?php
	$sql="Select * from produse";
	$sursa=mysqli_query($conn, $sql);
	while($row=mysqli_fetch_array($sursa))
      {
		  print '<tr>
		  <td>'.$row['id_produs'].'</td><td>';
		  $adrimag="imagini/".$row['id_produs'].".jpg";
	   if(file_exists($adrimag)){
		  $adrimag="imagini/".$row['id_produs'].".jpg";
		  print '<a href="'.$adrimag.'" ><img src="'.$adrimag.'" width="25" height="30"></td>';
        }else{
		print '<div style="width:25px; height:30px; border: 1px black solid;
          background-color:#cccccc";>Fara imagine</div></td>';
		  }
		 print '<td>'.$row['titlu'].'</td>';
		 
		 $sqlStele="Select avg(stele) as stars from rating where id_produs=".$row['id_produs'];
		 $sursaStele=mysqli_query($conn, $sqlStele);
		 $Stele=mysqli_fetch_array($sursaStele);
		 print '<td><a href="rating.php?id_produs='.$row['id_produs'].'">'.$Stele['stars'].'</a></td>';
		 
		 $sqlTip="Select tip from tipuri where id_tip=".$row['id_tip'];
		 $sursaTip=mysqli_query($conn, $sqlTip);
		 $Tip=mysqli_fetch_array($sursaTip);
		 print '<td>'.$Tip['tip'].'</td>';
		 
		 $sqlMarca="Select marca from marci where id_marca=".$row['id_marca'];
		 $sursaMarca=mysqli_query($conn, $sqlMarca);
		 $Marca=mysqli_fetch_array($sursaMarca);
		 print '<td>'.$Marca['marca'].'</td>';
		 
		 print '<td>'.$row['descriere'].'</td>';
		 print '<td>'.$row['pret'].'</td>';
		 print '<td>'.$row['datai'].'</td>';
		 if($row['cantitate']==0)
		 {
			 print '<td><p style="color:red;"><b>'.$row['cantitate'].'</b></p></td></tr>';
		 }
		 else{
			 print '<td>'.$row['cantitate'].'</td></tr>';
		 }
		 
	  }
	  ?>
		  
	