<?php
  session_start();
  include("autorizare.php");
  include("admin_top.php");
  include("conectare.php");
  
  if(isset($_POST['adauga_produs']))
{
  /* Verificam daca noul nume de tip a fost introdus. */ 
  if($_POST['id_produs']==""||$_POST['nr_buc']=="")
  {
 	print "Nu ati introdus id-ul produsului si numarul de bucati ! ";
  }
  else
  {
    $sql = "insert into vanzari(id_tranz,id_produs, nr_buc) values(".$_POST['id_tranz'].",".$_POST['id_produs'].",".$_POST['nr_buc'].")" ;
	mysqli_query($conn, $sql);
 	/*print '<br>'.$sql.'<br>';*/
 	print "produsul a fost adaugat!";
  }
}
?>
