<?php
  session_start();
  include("autorizare.php");
  include("admin_top.php");
  include("conectare.php")
  
?>
<h2>Adaugare</h2>

 <b>Adauga Tip</b>
  <form action="prelucrare_adaugare.php" method="POST">
   Tip nou : <INPUT type="text" name="tip_nou" style="background-color:rgba(0, 0, 0, 0);">
	         <INPUT type="submit" name="adauga_tip" value="Adauga" class="buton">
  </form>
 
 	<!--&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-->
	<br>
 <b>Adauga Marca</b>
  <form action="prelucrare_adaugare.php" method="POST">
     Marca noua : <INPUT type="text" name="marca_nou">
	            <INPUT type="submit" name="adauga_marca" value="Adauga" class="buton">
  </form>

 	<!--&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-->
	<br>

<b>Adauga Produs</b>
  <form action="prelucrare_adaugare.php" method="POST" enctype="multipart/form-data">
   <table >
    <tr>
     <td>Tip</td>
     <td>
     <select name="id_tip" style="background-color:rgba(0, 0, 0, 0);">
	
      <?php
        $sql="select * from tipuri order by tip asc";
        $sursa=mysqli_query($conn, $sql);
        while($row=mysqli_fetch_array($sursa))
		{
			print '<option value="'.$row['id_tip'].'">'.$row['tip'].'</option>';
        }
      ?>
     </select>
    </td>
   </tr>

	<tr>
     <td>Marca</td>
     <td>
     <select name="id_marca" style="background-color:rgba(0, 0, 0, 0);">
	
      <?php
        $sql="select * from marci order by marca asc";
        $sursa=mysqli_query($conn, $sql);
        while($row=mysqli_fetch_array($sursa))
		{
			print '<option value="'.$row['id_marca'].'">'.$row['marca'].'</option>';
        }
      ?>
     </select>
    </td>
   </tr>

   <tr>
     <td>Titlu:</td>
     <td><input type="text" name="titlu" style="background-color:rgba(0, 0, 0, 0);"></td>
    </tr>
 
    <tr>
     <td align="top">Descriere: </td>
     <td><textarea name="descriere" rows="8" style="background-color:rgba(0, 0, 0, 0);">
         </textarea>
     </td>
    </tr>
    
	
    <tr>
     <td>Pret: </td>
     <td><input type="text" name="pret"style="background-color:rgba(0, 0, 0, 0);"></td>
    </tr>
	
	<tr>
     <td>Cantitate: </td>
     <td><input type="text" name="cantitate"style="background-color:rgba(0, 0, 0, 0);"></td>
    </tr>
	
		<tr>
     <td>Data intare: </td>
     <td><input type="date" name="datai"style="background-color:rgba(0, 0, 0, 0);"></td>
    </tr>
	
	<tr>
	<td>Imagine: </td>
	<td> <input type="file" name="fileToUpload" id="fileToUpload"></td>
	</tr>
    <tr>
     <td></td>
     <td><INPUT type="submit" name="adauga_produs" value="Adauga" class="buton"></td>
    </tr>
	
   </table>
  </form>
 </body>
</html>