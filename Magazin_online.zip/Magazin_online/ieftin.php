<?php

include ("conectare.php");
include ("page_top.php");
include ("meniu.php");
?>

<td valign="top">
<h1> Cele mai ieftine produse!</h1>
<!--<br>-->

<table cellpadding="6" style="background-color:rgba(0, 0, 0, 0);">
<tr> 
<?php
$sql = "SELECT id_produs, titlu, marca, pret FROM produse, marci WHERE produse.id_marca=marci.id_marca ORDER BY pret ASC LIMIT 0,5";
$sursa=mysqli_query($conn, $sql);
while($row=mysqli_fetch_array($sursa))
      {
	   print '<td align = "center" style="width: 150px;">' ;
	   $adrimag="imagini/".$row['id_produs'].".jpg";
	   if(file_exists($adrimag)){
		  $adrimag="imagini/".$row['id_produs'].".jpg";
		  print '<img src="'.$adrimag.'" width="100" height="130"><br>';
        }else{
		print '<div style="width:75px; height:100px; border: 1px black solid;
          background-color:#F1E3F7";>Fara imagine</div>';
		  }
		  print '<b><a href="produs.php?id_produs='.$row['id_produs'].'">'
        .$row['titlu'].'</a></b><br>  <i>'
		.$row['marca'].'</i><br> pret: '
        .$row['pret'].' lei
        </td>';
		}
	  ?>
	  </tr>
	  </table>

<?php
	  include("page_bottom.php")
?>