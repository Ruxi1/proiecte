<?php
session_start();
include ("conectare.php");
include ("page_top.php");
include ("meniu.php");
?>
<td valign="top">
<h2 align="center">Despre</h2>
<p> Acesta este un magazin online detinut de Baros Ruxandra si este destinat vanzarii mai multor tipuri de produse.</p>

<br>
<h1> Termeni si conditii </h1>
<br>
<p> Livrarea se face la domiciliu, fara cost suplimentar.</p>
<p> Singura modalitate de plata este cea de ramburs la livrare.</p>
<p> Datele personale oferite site-ului nu vor fi folosite cu alte scopuri.</p>


<?php
	  include("page_bottom.php")
?>