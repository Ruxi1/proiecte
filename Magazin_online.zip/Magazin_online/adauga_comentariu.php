<?php
	if ($_POST['nume_utilizator'] == "" ||
	$_POST['adresa_email'] == "" ||
	$_POST['comentariu'] == "")
	{
		print "Trebuie sa completati toate campurile";
		exit;
	}

	//$email = test_input($_POST["adresa_email"]);
if (!filter_var($_POST["adresa_email"], FILTER_VALIDATE_EMAIL)) {
  print "Invalid email format";
  exit;
}
	
	include("conectare.php");

	$nume = strip_tags($_POST['nume_utilizator']);
	$email = strip_tags($_POST['adresa_email']);
	$coment = strip_tags($_POST['comentariu']);
    $sql="INSERT INTO comentarii(id_produs, nume_utilizator, adresa_email, comentariu)
	VALUES(".$_POST['id_produs'].",'".$nume."','".$email."','".$coment."')";
//$sql="insert into comentarii values(".$_POST['id_produs'].",'".$nume."','".$email."','".$coment."')";
	mysqli_query($conn, $sql);
	$inapoi="produs.php?id_produs=".$_POST['id_produs'];
	$id_produs=$_POST['id_produs'];
	header("location: $inapoi");
?>
  

