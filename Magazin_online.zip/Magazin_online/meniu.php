  <td valign="top" width="400">
    <div style="width:200px; background-color: #F1E3F7; padding:4px; box-shadow: 2px 2px 20px 23px #F1E3F7">
      <b>Alege tipul produsului</b>
      <hr size="1">
		<a href="toate.php">Toate</a><br>
        <?php
          $sql = " SELECT * FROM tipuri ORDER BY tip ASC ";
          $sursa = mysqli_query($conn, $sql);
          while($row=mysqli_fetch_array($sursa))
          {
            print '<a href="tip.php?id_tip='.$row['id_tip'].'">'.$row['tip'].'</a><br>' ;
          }
        ?>
    </div>
	<div style="width:200px; background-color: #F1E3F7; padding:4px; box-shadow: 2px 2px 20px 23px #F1E3F7">
	<hr size="1">
      <form action="cautare.php" method="GET">
        <b>Cautare</b><br>
        <input type="text" name="cuvant" size="20"><br>
        <input type="submit" value="Cauta" class="buton">
      </form>
    </div>
	
    <div style="width:200px; background-color:#F1E3F7; padding:4px; box-shadow: 2px 2px 20px 23px #F1E3F7">
	<hr size="1">
    <b>Cos</b><br>
    <?php
      $nrProduse=0;
      $totalValoare=0;
	  if(isset($_SESSION['titlu']))
	  {
		  for($i=0; $i < count($_SESSION['titlu']); $i++)
		  {
			$nrProduse = $nrProduse + $_SESSION['nr_buc'][$i];
			$totalValoare=$totalValoare+$_SESSION['nr_buc'][$i]*$_SESSION['pret'][$i];
		  }
	  }
    ?>
    Aveti <b><?=$nrProduse?></b> produse in cos, in valoare totala de <b><?=$totalValoare?></b> lei.
    <a href="cos.php">Click aici pentru a vedea continutul cosului</a>
    </div>
</td>