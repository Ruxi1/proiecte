<?php
session_start();
include ("conectare.php");
include ("page_top.php");
include ("meniu.php");
?>
<td valign="top">
<h1> Pagina Principala</h1>
<!--<br>-->
<b>Cele mai noi produse </b>
<table cellpadding="6" style="background-color:rgba(0, 0, 0, 0);">
<tr> 
<?php
$sql = "SELECT id_produs, titlu, marca, pret FROM produse, marci WHERE produse.id_marca=marci.id_marca ORDER BY datai DESC LIMIT 0,5";
$sursa=mysqli_query($conn, $sql);
while($row=mysqli_fetch_array($sursa))
      {
	   print '<td align = "center" style="width: 150px;">' ;
	   $adrimag="imagini/".$row['id_produs'].".jpg";
	   if(file_exists($adrimag)){
		  $adrimag="imagini/".$row['id_produs'].".jpg";
		  print '<img src="'.$adrimag.'" width="100" height="130"><br>';
        }else{
		print '<div style="width:75px; height:100px; border: 1px black solid;
          background-color:#F1E3F7";>Fara imagine</div>';
		  }
		  print '<b><a href="produs.php?id_produs='.$row['id_produs'].'">'
        .$row['titlu'].'</a></b><br>  <i>'
		.$row['marca'].'</i><br> pret: '
        .$row['pret'].' lei
        </td>';
		}
	  ?>
	  </tr>
	  </table>
	  <hr>
  
  <b>Cele mai populare produse</b>
  <table cellpadding="5">
    <tr>
    <?php
		$sqlVanzari = "SELECT id_produs, sum(nr_buc) AS bucatiVandute FROM vanzari GROUP BY id_produs ORDER BY bucatiVandute DESC LIMIT 0,5";
		$resursaVanzari=mysqli_query($conn, $sqlVanzari);
		while($rowVanzari=mysqli_fetch_array($resursaVanzari)){
		  $sqlProdus="SELECT id_produs, titlu,pret FROM produse where id_produs=".$rowVanzari['id_produs'];
		  $resursaProdus=mysqli_query($conn,$sqlProdus);
		  while($rowProdus=mysqli_fetch_array($resursaProdus)){
			  ?>
			  <td align="center" style="width:150px;">
			  <?php
			  $adresImg="Imagini/".$rowProdus['id_produs'].".jpg";
			  if(file_exists($adresImg)){
				  $adresImg="Imagini/".$rowProdus['id_produs'].".jpg";
				  print '<img src="'.$adresImg.'" width="100" height="130"><br>';
			  }
			  else
			  {
				  print '<div style="width:75px; height:100px;  border: 1px black solid; background-color:#F1E3F7">fara imagine</div>';
			  }
			  print '<b><a href="produs.php?id_produs='.$rowVanzari['id_produs'].'"><br>
          '.$rowProdus['titlu'].'</a></b><br>
          pret: '.$rowProdus['pret'].' lei </td>';
		  }
	  }
	  ?>
	  </tr>
	  </table>
	  </td>
	  </tr>
	  </table>
	  <br><br><br>
	  <?php
	  include("page_bottom.php")
?>