<?php
session_start();
include ("conectare.php");
include ("page_top.php");
include ("meniu.php");
?>
<td valign="top">
<h2 align="left">Contact</h2>
<p><img src="rosu.jpeg" width="85" height="100" style="vertical-align:middle"><br> Baros Ruxandra-Maria<br>
mail:<a href="mailto:ruxandramaria.baros@ulbsibiu.ro">ruxandramaria.baros@ulbsibiu.ro</a><br>

<b>Locatie:</b></p>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d695.4017349087292!2d24.175223729360958!3d45.79910179999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x474c670af00df6b7%3A0x99a02a9854126664!2sStrada%20Corneliu%20Diaconovici%201a%2C%20Sibiu!5e0!3m2!1sro!2sro!4v1679571794237!5m2!1sro!2sro" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
<?php
	  include("page_bottom.php")
?>