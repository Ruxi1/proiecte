<?php
	session_start();
	include("conectare.php");
	include("page_top.php");
	include("meniu.php");
?>
<td valign="top">
Acestea sunt produsele comandate de dvs.:<br><br>
<table border="1" cellspacing="0" cellpading="4" style="background-color:rgba(0, 0, 0, 0);">
	<tr bgcolor="#F9F1E7">
		<td align="center"><b>Nr.buc</b></td>
		<td align="center"><b>Produs </b></td>
		<td align="center"><b>Pret </b></td>
		<td align="center"><b>Total </b></td>
	</tr>
<?php
	$totalGeneral =0;
	if($_SESSION!=null){
	for($i=0;$i<count($_SESSION['id_produs']);$i++)
	{
		if($_SESSION['nr_buc'][$i] !=0)
		{
			print '<tr>
			<td align="center">'.$_SESSION['nr_buc'][$i].'</td><td><b>'
			.$_SESSION['titlu'][$i].'</td>
			<td align="right">'.$_SESSION['pret'][$i].' lei</td>
			<td align="right">'
			.($_SESSION['nr_buc'][$i]*$_SESSION['pret'][$i]).' lei </td>
			</tr>';
			$totalGeneral = $totalGeneral + ($_SESSION['nr_buc'][$i] * $_SESSION['pret'][$i]);
		}
	}
	//afisam totalul general
	print '<tr>
	<td align="right" colspan="3"><b>Total de plata</b></td>
	<td align="right"><b>'.$totalGeneral.'</b> lei</td>
	</tr>';
?>
</table>
<h3>Detalii livrare</h3>
Introduceti numele si adresa unde doriti sa primiti produsele cumparate:
<form action="prelucrare.php" method="POST">
<table>
	<tr>
	<td><b>Numele:</b></td>
	<td><input type="text" name="nume" style="background-color:rgba(0, 0, 0, 0);"></td>
	</tr>
	<tr>
	<td><b>Adresa de email:</b></td>
	<td><input type="text" name="email" style="background-color:rgba(0, 0, 0, 0);"></td>
	</tr>
	<tr>
	<td><b>Numarul de telefon:</b></td>
	<td><input type="text" name="telefon" style="background-color:rgba(0, 0, 0, 0);"></td>
	</tr>
	<tr>
	<td valign="top"><b>Adresa de livrare:</b></td>
	<td><textarea name="adresa" rows="6"style="background-color:rgba(0, 0, 0, 0);"></textarea></td>
	</tr>
	<td valign="top"><b>Comentariu extra:</b></td>
	<td><textarea name="extra" rows="6"style="background-color:rgba(0, 0, 0, 0);"></textarea></td>
	</tr>
	<tr>
	<td></td>
	<td><input type="submit" value="Trimite" class="buton"></td>
	</tr>
</table>
</form>
</td>
<?php
	}
	else
	{
		print 'Nu aveti produse in cos!';
	}
	include("page_bottom.php");
?>