<?php
	session_start();
	include("conectare.php");
	include("page_top.php");
	include("meniu.php");
	//$actiune = $_GET['actiune'];
	
	if(isset($_GET['actiune']) && $_GET['actiune'] == "adauga")
	{
		$_SESSION['id_produs'][] = $_POST['id_produs'];
		$_SESSION['nr_buc'][] = 1;
		$_SESSION['pret'][] = $_POST['pret'];
		$_SESSION['titlu'][] = $_POST['titlu'];
		$_SESSION['marca'][] = $_POST['marca'];
	}
	if(isset ($_GET['actiune']) && $_GET['actiune'] == "modifica")
	{
		for($i=0; $i<count ($_SESSION['id_produs']); $i++)
		{
			$_SESSION['nr_buc'][$i] = $_POST['noulNrBuc'][$i];
		}
	}
	
?>
<td valign="top">
	<h2>Cosul de cumparaturi</h2>
	<form action="cos.php?actiune=modifica" method="POST">
		<table border="1" cellspacing="0" cellpading="4" style="background-color:rgba(0, 0, 0, 0);">
		<tr bgcolor="#F9F1E7" style="background-color:rgba(0, 0, 0, 0);">
			<td align="center"><b>Nr_buc</b></td>
			<td align="center"><b>Produs </b></td>
			<td align="center"><b>Pret </b></td>
			<td align="center"><b>Total </b></td>
		</tr>
	<?php
	$totalGeneral=0;
	if(isset($_SESSION['id_produs'])){
	for($i=0; $i<count($_SESSION['id_produs']); $i++)
	{
		if($_SESSION['nr_buc'][$i] !=0)
		{
			/*doar daca numarul de bucati nu este 0, afiseaza randul*/
			print '<tr>
			<td><input type="text" name="noulNrBuc['.$i.']" size="1"
			value="'.$_SESSION['nr_buc'][$i].'"></td>
			<td><b><a href="produs.php?id_produs='.$_SESSION['id_produs'][$i].'">'.$_SESSION['titlu'][$i].'</b> 
			<td align="right">'.$_SESSION['pret'][$i].' lei</td>
			<td align="right">'.($_SESSION['nr_buc'][$i]*$_SESSION['pret'][$i]).' lei </td>
			</tr>';
			$totalGeneral= $totalGeneral + ($_SESSION['nr_buc'][$i]*$_SESSION['pret'][$i]);
		}
	}
	
	

	
	print '<tr>
	<td align="right" colspan="3"><b>Total in cos</b></td>
	<td align="right"><b>'.$totalGeneral.'</b> lei</td>
	</tr>';
	?>
	</table>
	
	
	<input type="submit" value="Modifica">
	<br><br>
		Introduceti <b>0</b> pentru produsele pe care doriti sa le scoateti din cos!
	<table>
		<tr>
			<td width="200" height="30" align="center">
			<a href="index.php"><img src="cos.gif" width="140" height="150"> <br>Continua cumparaturile</a></td>
			<td width="200" height="30" align="center">
			<a href="casa.php"><img src="casa.gif" width="130" height="150"><br>Comanda</a></td>
		</tr>
	</table>
	<?php
	}
	else 
	{print '<td align="center"><b> Cosul este gol!</b></td>
	<td><a href="index.php"><img src="cos.gif" width="140" height="150"></a></td>';}

	include("page_bottom.php");
?>
