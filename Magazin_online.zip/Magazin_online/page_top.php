<html>
<head>
     <meta http-equiv="Content-Type" content="text/html;charset=iso-8859-2">
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     <title>Magazin online</title>
</head>
    <style type="text/css">
	.checked {
  color: orange;
}
	body,p,td
	{
		font-family: Verdana, Arial, sans-serif;
		font-size:12px;
	}
	h1{
		font-family:"Times New Roman",Times,serif;
		font-size:18px;
		font-weight: bold;
    color: #8839AB;
    font-style: italic;
  }
  titlu
  {
    font-family: Verdana, Arial, sans-serif;
    font-size: 14px;
    font-weight: bold;
    color: #0066CC;
  }
  .buton
  {
	  background-color: #833D97;
      color: #FFFFFF;
  }
  a:link {
  color: purple;
	}
  a:visited {
	color: purple;
	}
	a:hover {
  color: red;
}

  
  </style>
<body bgcolor="#ffffff" background="imgp.png">
  <img src="logo.jpg"  width="700" height="150">
  <button onclick="document.location='despre.php'" style="background-color: #F1E3F7;">Despre</button>
  <button onclick="document.location='contact.php'" style="background-color: #F1E3F7;">Contact</button>
  <button onclick="document.location='index.php'" style="background-color: #F1E3F7;">&copy; Home</button>
  <button onclick="document.location='ieftin.php'" style="background-color: #F1E3F7;">Produse ieftine</button>
  <br><br>
  <table>
    <tr>