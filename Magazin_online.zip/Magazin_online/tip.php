<?php
	session_start();
	include ("conectare.php");
	include ("page_top.php");
	include ("meniu.php");
	
	$id_tip=$_GET['id_tip'];
	$sqlNumeTip="SELECT tip FROM tipuri WHERE id_tip =".$id_tip;
	$sursaNumeTip = mysqli_query($conn, $sqlNumeTip);
	$row=mysqli_fetch_array($sursaNumeTip);
	$numeTip = $row['tip'];
?>
<td valign="top">
<h3 align="center">Tip: <?=$numeTip?></h3>

<table cellpadding="5">
<?php
	$sql="SELECT id_produs,id_marca, titlu, descriere, pret
	FROM produse, tipuri
	WHERE produse.id_tip=tipuri.id_tip AND
	tipuri.id_tip = ".$id_tip;
	$sursa = mysqli_query($conn, $sql);
	$x=1;
	while($row = mysqli_fetch_array($sursa))
	{
		$sqlmarca="Select marca from marci where id_marca=".$row['id_marca'];
		$sursamarca=mysqli_query($conn, $sqlmarca);
		$marca=mysqli_fetch_array($sursamarca);
		 ?>
		<td align = "center" style="width: 150px;">
<?php
		$adrimag="Imagini/".$row['id_produs'].".jpg";
		if (file_exists($adrimag))
		{
			$adrimag="Imagini/".$row['id_produs'].".jpg";
		    print '<img src="'.$adrimag.'" width="100" height="130"><br>';
		}
		else
		{
			/*daca nu exista fis specificat afisam layerul DIV in care scrie "fara imagine"*/
			print '<div style="width:75px; border: 1px black solid;
			background-color:#cccccc">fara imagine</div>';
		}
?>
		</td>
		<td>
			<b><a href="produs.php?id_produs=<?=$row['id_produs']?>">
			<?=$row['titlu']?></a></b><br>
			<?=$marca['marca']?><br>
			pret: <?=$row['pret']?> lei
		</td>
		<?php
		if($x%3==0){
?>
		</tr><?php } 
		$x=$x+1;?>
<?php
	}
?>
</table>
</td>
<?php
	include ("page_bottom.php");
?>