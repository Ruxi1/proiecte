<?php
	if ($_POST['nume_utilizator'] == "" ||
	$_POST['email'] == "" ||
	$_POST['stele'] == "")
	{
		print "Trebuie sa completati toate campurile";
		exit;
	}
	if(!is_numeric($_POST['stele']))
	{
		print "Campul stele trebuie sa fie un numar intre  1 si 5";
		exit;
	}
	if( !$_POST['stele']=="1" || !$_POST['stele']=="2" || !$_POST['stele']=="3" || !$_POST['stele']=="4" || !$_POST['stele']=="5")
	{
		print "Campul stele trebuie sa fie un numar intre  1 si 5";
		exit;
	}

	//$email = test_input($_POST["adresa_email"]);
if (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
  print "Invalid email format";
  exit;
}
	
	include("conectare.php");

	$nume = strip_tags($_POST['nume_utilizator']);
	$email = strip_tags($_POST['email']);
	$stele = strip_tags($_POST['stele']);
    $sql="INSERT INTO rating(id_produs, nume_utilizator, email, stele)
	VALUES(".$_POST['id_produs'].",'".$nume."','".$email."','".$stele."')";
	mysqli_query($conn, $sql);
	$inapoi="produs.php?id_produs=".$_POST['id_produs'];
	$id_produs=$_POST['id_produs'];
	header("location: $inapoi");
?>