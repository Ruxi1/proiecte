<?php
    session_start();
	include("conectare.php");
	include("page_top.php");
	include("meniu.php");
	$id_produs=$_GET['id_produs'];
	$sql="SELECT titlu, marca, descriere, pret, cantitate FROM produse, marci WHERE id_produs=".$id_produs." AND produse.id_marca=marci.id_marca";
	$resursa = mysqli_query($conn, $sql);
	$row = mysqli_fetch_array($resursa);
?>
<td valign="top">
<table>
<tr>
<td valign="top">
<?php
	$adrsImg="Imagini/".$id_produs.".jpg";
   if (file_exists($adrsImg))
	{	
		$adrsImg="Imagini/".$id_produs.".jpg";
	    print '<a href="'.$adrsImg.'" > <img src="'.$adrsImg.'" width="100" height="130"></a><br>';
	}
	else
	{
		print '<div style="width:75px; height:100px; border: 1px black solid;
		background-color: #F1E3F7">fara imagine</div>';
	}
	
?>
    </td>
	<td valign="top">
	<h1><?=$row['titlu']?></h1>
	<?php
	$sqlstar="Select avg(stele) as stars from rating where id_produs=".$id_produs;
	$resursastele=mysqli_query($conn, $sqlstar);
	$rowstele=mysqli_fetch_array($resursastele);
	if($rowstele['stars']!=0 && $rowstele['stars']!=null)
	{
		if(round($rowstele['stars'])==1)
		{
			?>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star"></span>
			<span class="fa fa-star"></span>
			<span class="fa fa-star"></span>
			<span class="fa fa-star"></span>
			<?php
		}
		if(round($rowstele['stars'])==2)
		{
			?>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star"></span>
			<span class="fa fa-star"></span>
			<span class="fa fa-star"></span>
			<?php
		}
		if(round($rowstele['stars'])==3)
		{
			?>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star"></span>
			<span class="fa fa-star"></span>
			<?php
		}
		if(round($rowstele['stars'])==4)
		{
			?>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star"></span>
			<?php
		}
		if(round($rowstele['stars'])==5)
		{
			?>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<span class="fa fa-star checked"></span>
			<?php
		}
			
	}
	else
	{
		print '<i>nu exista rating pentru acest produs</i>';
	}
		
	?>
	<br><br>
	<b><?=$row['marca']?></b>
	<p> <?=$row['descriere']?></p>
	<p><b>pret: <?=$row['pret']?> lei </b></p>
	<td>
	</tr>
	</table>
	<?php
	if($row['cantitate']<=0)
	{
		print '<div style="color:#FB0505"><h2> Stoc indisponibil</h2></div>';
	}
	if($row['cantitate']>0){
	?>
	<form action="cos.php?actiune=adauga" method="POST">
		<input type="hidden" name="id_produs" value="<?=$id_produs?>">
		<input type="hidden" name="titlu" value="<?=$row['titlu']?>">
		<input type="hidden" name="marca" value="<?=$row['marca']?>">
		<input type="hidden" name="pret" value="<?=$row['pret']?>">
		<input type="submit" value="Cumpara acum!" class="buton">
	</form>
	<?php
	}
	?>
	<p><h1>Opiniile cumparatorilor</h1></p>
<?php
	$sqlComent="SELECT * FROM comentarii WHERE id_produs =" . $id_produs;
	$sursaComent = mysqli_query($conn, $sqlComent);
	$sqlLastCom="Select max(ultimul_comentariu_moderat) as lastCom from admin";
	$sursaLastCom=mysqli_query($conn,$sqlLastCom);
	$lastCom=mysqli_fetch_array($sursaLastCom);
	while ($row = mysqli_fetch_array($sursaComent))
	{
		if($row['id_comentariu']<=$lastCom['lastCom']){
		print ' <div style = "width:400px; border:1px solid #ffffff;
		background-color:#F1E3F7; padding:5px">
		 <b>'
		.$row['nume_utilizator'] . '</b><br>'
		.$row['comentariu'] . '</div> ';
		}
	}
?>
	<br>
	<div style="width:450px; border:1px solid #632415;
	background-color:#F1E3F7; adding:5px">
	<b>Adauga opinia ta</b><i>(comentariul va fi vizibil dupa moderare)</i>
	<hr size="1">
	<form action="adauga_comentariu.php" method="POST">
	&nbsp; nume: <input type="text" name="nume_utilizator"><br><br>
	&nbsp; email: <input type="text" name="adresa_email"><br><br>
	&nbsp; Comentariu: <br>&nbsp;
	<textarea name="comentariu" cols="45"></textarea>
	<br><br>
	<input type="hidden" name="id_produs" value="<?=$id_produs?>">
	<center>
	<input type ="submit" value="Adauga" class="buton">
	</center>
	</form>
	</div>
	
	<br>
	<div style="width:450px; border:1px solid #632415;
	background-color:#F1E3F7; adding:5px">
	<b>Ofera stele</b>
	<hr size="1">
	<form action="adauga_stele.php" method="POST">
	&nbsp; nume: <input type="text" name="nume_utilizator"><br><br>
	&nbsp; email: <input type="text" name="email"><br><br>
	&nbsp; stele(numar intre 1 si 5): <input type="text" name="stele"><br><br>
	
	<input type="hidden" name="id_produs" value="<?=$id_produs?>">
	<center>
	<input type ="submit" value="Adauga" class="buton">
	</center>
	</form>
	</div>
	
	</td>
<?php
	include("page_bottom.php");
?>

