<?php
	session_start();
	include("conectare.php");
	include("page_top.php");
	include("meniu.php");
	$cuvant = $_GET['cuvant'];
?>
<td valign="top">
<h1>Rezultatele căutării</h1>
<p>Textul căutat: <b><?=$cuvant?></b></p>
<b>Marci</b> 
<blockquote>
<?php
$sql = "SELECT id_marca, marca FROM marci WHERE marca LIKE '%".$cuvant."%'";
$resursa = mysqli_query($conn, $sql);
if(mysqli_num_rows($resursa) ==0)                                 
{
	print "<i>Nici un rezultat printre marci</i>";
}
else{
$res=mysqli_fetch_array($resursa);
$sql2="SELECT id_produs, titlu, id_marca FROM produse WHERE id_marca=".$res['id_marca'];
$resursa2= mysqli_query($conn, $sql2);
while($row = mysqli_fetch_array($resursa2)) 
{
	$nume_marca = str_replace ($cuvant,"<b>$cuvant</b>", $res['marca']);
	$adrimag="imagini/".$row['id_produs'].".jpg";
	   if(file_exists($adrimag)){
		  $adrimag="imagini/".$row['id_produs'].".jpg";
		  print '<img src="'.$adrimag.'" width="75" height="100"><br>';
        }else{
		print '<div style="width:75px; height:100px; border: 1px black solid;
          background-color:#F1E3F7";>Fara imagine</div>';
		  }
	print '<a href="produs.php?id_produs='.$row['id_produs'].'">'.$row['titlu'].
	'</a><br>'.$nume_marca.'<br><br>';
}
}
?>
</blockquote>
<b>Titluri</b> 
<blockquote>
<?php
$sql = "SELECT id_produs, titlu FROM produse WHERE titlu LIKE '%".$cuvant."%'";
$resursa = mysqli_query($conn, $sql);
if(mysqli_num_rows($resursa) == 0)
{
	print "<i>Nici un rezultat printre titluri</i>";
}
while($row = mysqli_fetch_array($resursa)) 
{
	$titlu = str_replace ($cuvant,"<b>$cuvant</b>",$row['titlu']);
	$adrimag="imagini/".$row['id_produs'].".jpg";
	   if(file_exists($adrimag)){
		  $adrimag="imagini/".$row['id_produs'].".jpg";
		  print '<img src="'.$adrimag.'" width="75" height="100"><br>';
        }else{
		print '<div style="width:75px; height:100px; border: 1px black solid;
          background-color:#F1E3F7";>Fara imagine</div>';
		  }
	print '<a href="produs.php?id_produs='.$row['id_produs'].'">'.$row['titlu'].
	'</a><br>'.$titlu.'<br><br>';
}
?>
</blockquote>
<b>Descrieri</b>
<blockquote>
<?php
$sql = "SELECT id_produs,titlu, descriere FROM produse WHERE descriere LIKE '%".$cuvant."%'";
$resursa = mysqli_query($conn, $sql);
if(mysqli_num_rows($resursa) == 0) 
{
	print "<i>Nici un rezultat in descrieri</i>";
}
while($row = mysqli_fetch_array($resursa)) 
{
$descriere = str_replace ($cuvant,"<b>$cuvant</b>", $row['descriere']);
$adrimag="imagini/".$row['id_produs'].".jpg";
	   if(file_exists($adrimag)){
		  $adrimag="imagini/".$row['id_produs'].".jpg";
		  print '<img src="'.$adrimag.'" width="75" height="100"><br>';
        }else{
		print '<div style="width:75px; height:100px; border: 1px black solid;
          background-color:#F1E3F7";>Fara imagine</div>';
		  }
print '<a href="produs.php?id_produs='.$row['id_produs'].'">'.$row['titlu'].
'</a><br>'.$descriere.'<br><br>';
}
?>
</blockquote>
</td>
<?php
	include("page_bottom.php");
?>