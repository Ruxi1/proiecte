<?php
	session_start();
	include ("conectare.php");
	include ("page_top.php");
	include ("meniu.php");
?>
<td valign="top">
<h3 align="center">Tip: Toate</h3>
<table cellpadding="6" align="center">
<?php	
	$sql="SELECT id_produs, titlu, marca, pret FROM produse, marci WHERE produse.id_marca=marci.id_marca";
	$sursa = mysqli_query($conn, $sql);
	$x=1;
	while($row = mysqli_fetch_array($sursa))
	{
		
		?>
		<td align = "center" style="width: 150px;">
<?php
		
		$adrimag="Imagini/".$row['id_produs'].".jpg";
		if (file_exists($adrimag))
		{
			$adrimag="Imagini/".$row['id_produs'].".jpg";
		    print '<img src="'.$adrimag.'" width="100" height="130"><br>';
		}
		else
		{
			/*daca nu exista fis specificat afisam layerul DIV in care scrie "fara imagine"*/
			print '<div style="width:75px; border: 1px black solid;
			background-color:#cccccc">fara imagine</div>';
		}
?>
		</td>
		<td>
			<b><a href="produs.php?id_produs=<?=$row['id_produs']?>">
			<?=$row['titlu']?></a></b><br>
			<?=$row['marca']?></a></b><br>
			pret: <?=$row['pret']?> lei
		</td>
		<?php
		if($x%3==0){
?>
		</tr><?php } 
		$x=$x+1;?>
<?php
	}
?>
</table>
</td>
<?php
	include ("page_bottom.php");
?>