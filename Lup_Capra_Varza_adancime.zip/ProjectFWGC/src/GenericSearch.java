// GenericSearch.java
// From Classic Computer Science Problems in Java Chapter 2
// Copyright 2020 David Kopec
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.ToDoubleFunction;

public class GenericSearch {

	public static <T> Node<T> dfs(T initial, Predicate<T> goalTest,
			Function<T, List<T>> successors) {
		// frontier is where we've yet to go
		Stack<Node<T>> frontier = new Stack<>();
		frontier.push(new Node<>(initial, null));
		// explored is where we've been
		Set<T> explored = new HashSet<>();
		explored.add(initial);

		// keep going while there is more to explore
		while (!frontier.isEmpty()) {
			Node<T> currentNode = frontier.pop();
			T currentState = currentNode.state;
			// if we found the goal, we're done
			if (goalTest.test(currentState)) {
				return currentNode;
			}
			// check where we can go next and haven't explored
			for (T child : successors.apply(currentState)) {
				if (explored.contains(child)) {
					continue; // skip children we already explored
				}
				explored.add(child);
				frontier.push(new Node<>(child, currentNode));
			}
		}
		return null; // went through everything and never found goal
	}

	public static <T> List<T> nodeToPath(Node<T> node) {
		List<T> path = new ArrayList<>();
		path.add(node.state);
		// work backwards from end to front
		while (node.parent != null) {
			node = node.parent;
			path.add(0, node.state); // add to front
		}
		return path;
	}



}
