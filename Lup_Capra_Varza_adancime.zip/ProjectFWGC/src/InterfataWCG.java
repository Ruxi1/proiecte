
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
class InterfataWCG extends JFrame implements ActionListener {

    // JFrame
    static JFrame f;

    // JButton
    static JButton b;

    // text area
    static JTextArea jt;

    // default constructor
    InterfataWCG()
    {
    }


    public static void main(String[] args)
    {

        f = new JFrame("Farmer Wolf Cabbage Goat");

        b = new JButton("Start");

        InterfataWCG te = new InterfataWCG();

        b.addActionListener(te);

        jt = new JTextArea(20, 20);

        JPanel p = new JPanel();

        p.add(jt);
        p.add(b);


        f.add(p);
        // set the size of frame
        f.setSize(400, 400);

        f.show();

        jt.setEditable(false);
    }

    // if the button is pressed
    public void actionPerformed(ActionEvent e)
    {
        String s = e.getActionCommand();
        List<String> sollutionList = new ArrayList<>();

        WCGState start = new WCGState(1, 1, 1, true);
        Node<WCGState> solution = GenericSearch.dfs(start, WCGState::goalTest, WCGState::successors);
        if (solution == null) {
            jt.setText("path not found");
        } else {
            List<WCGState> path = GenericSearch.nodeToPath(solution);
            sollutionList= WCGState.displaySolutionList(path);
        }
        if (s.equals("Start")) {
            // print the solution
            for(int i=0;i<sollutionList.size();i++)
            {
                jt.append(sollutionList.get(i));
            }

        }
    }
}
